# Akshay Wake Word Detection

ESP32-based local wake-word detection for the word **“Akshay”** using an ESP32 DevKit V1 (ESP32-WROOM-32), INMP441 I2S microphone, and TensorFlow Lite Micro. When the model detects the wake word above its configured threshold, an LED on GPIO4 flashes.

## Folders
- `firmware/` — Arduino sketch and model header (add your working `.ino` and `akshay_model_small.h`).
- `model/` — TensorFlow Lite model and metadata.
- `training/` — training notebook.
- `docs/` — wiring and test results.

## Hardware and wiring

| INMP441 | ESP32 |
|---|---|
| VDD | 3.3V |
| GND | GND |
| SCK / BCLK | GPIO26 |
| WS / LRCL | GPIO25 |
| SD | GPIO33 |
| L/R | GND |

LED: GPIO4 → current-limiting resistor → LED anode (+); LED cathode (−) → GND.

## Model details
- Sample rate: 16 kHz; window: 1 second
- MFCC: 13 coefficients; expected input shape: `[1, 101, 13, 1]`
- Classes: Akshay (0), Unknown (1), Silence (2)

## Observed test output
One serial capture showed Akshay 0.9974, Unknown 0.0026, Silence 0.0000, inference time 26 ms, and detection count 3. This is one observed test, not a comprehensive accuracy or false-trigger evaluation. MFCC processing was reported around 250–258 ms in another run.

## Arduino setup
Install Arduino IDE 2.x, the ESP32 board package, and the `TensorFlowLite_ESP32` library. Keep the `.ino` and `akshay_model_small.h` together, select the ESP32 DevKit V1 and correct port, upload, then open Serial Monitor at 115200 baud.

## Note
The trained `.tflite` model, model header, and final verified `.ino` were not attached as files here, so they are not included in this starter package. Add your own copies before publishing.
