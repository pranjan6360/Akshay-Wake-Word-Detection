# Test Results

One observed Serial Monitor capture:
- Akshay score: 0.9974
- Unknown score: 0.0026
- Silence score: 0.0000
- Inference time: 26 ms
- Detection count shown: 3

Another run reported MFCC processing time around 250–258 ms.

These are individual observations, not a measured accuracy or false-activation rate. For evaluation, test repeated wake-word utterances, unrelated speech, and silence/noise, then record true detections and false activations.
