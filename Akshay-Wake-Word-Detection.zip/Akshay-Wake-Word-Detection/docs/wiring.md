# Wiring

## INMP441 → ESP32 DevKit V1
- VDD → 3.3V
- GND → GND
- SCK/BCLK → GPIO26
- WS/LRCL → GPIO25
- SD → GPIO33
- L/R → GND

## LED
GPIO4 → current-limiting resistor → LED anode (+); LED cathode (−) → GND.
