# Firmware

Add your final working `akshayWakeWord.ino` and `akshay_model_small.h` here. Keep both files together for Arduino IDE. The model header was not attached in this conversation.
