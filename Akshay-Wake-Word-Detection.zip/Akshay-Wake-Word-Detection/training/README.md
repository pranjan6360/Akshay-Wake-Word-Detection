# Training

`SIHHACKTHON.ipynb` is the notebook attached in this conversation, copied here as a starting point. If it is not your final training notebook, download the correct notebook from Colab using File → Download → Download .ipynb and replace/add it here. Avoid uploading private voice recordings or datasets unless you have permission to share them.
